// Hack Scanner Popup Logic - fully self-contained, zero messaging dependency
let currentReport = null, currentURL = '', mode = 'manual';

const scanBtn = document.getElementById('scan-btn');
const currentUrlEl = document.getElementById('current-url');
const resultsDiv = document.getElementById('results');
const emptyStateDiv = document.getElementById('empty-state');
const scanningStatus = document.getElementById('scanning-status');
const exportJsonBtn = document.getElementById('export-json');

document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.url?.startsWith('http')) { currentURL = tab.url; currentUrlEl.textContent = currentURL; }
  chrome.storage.local.get(['config'], (items) => {
    if (items.config?.autoScan) { mode = 'auto'; document.getElementById('mode-auto').checked = true; }
    else { mode = 'manual'; document.getElementById('mode-manual').checked = true; }
  });
  if (mode === 'auto' && currentURL) triggerScan();
});

document.querySelectorAll('input[name="mode"]').forEach(radio => {
  radio.addEventListener('change', (e) => { mode = e.target.value; chrome.storage.local.set({ config: { autoScan: mode === 'auto' } }); });
});

scanBtn.addEventListener('click', triggerScan);
exportJsonBtn.addEventListener('click', () => { if (currentReport) currentReport.downloadJSON(`hack_report_${new Date().toISOString().slice(0,10)}.json`); });

async function triggerScan() {
  if (!currentURL) return;
  showScanning(true); hideResults();
  try {
    const rH = await scanHeaders(currentURL);
    const rXss = await detectXSS();
    const rSql = await detectSQLi();
    const rCors = await detectCORS();
    const rSsrf = await detectSSRF();
    const rHttp = await detectHTTPMethods();
    const rFp = await detectFingerprint();

    currentReport = new ScanReport();
    currentReport.setTarget(currentURL);
    currentReport.setMode(mode);

    if (rH?.results) for (const [n, info] of Object.entries(rH.results)) { if (!info.present) currentReport.addFinding({ name: `Missing Header: ${n}`, severity: getHeaderSeverity(n), detail: info.issue || n + ' missing', remediation: 'Add "' + n + '" header' }); }
    for (const f of rXss) currentReport.addFinding(f);
    for (const f of rSql) currentReport.addFinding(f);
    for (const f of rCors) currentReport.addFinding(f);
    for (const f of rSsrf) currentReport.addFinding(f);
    for (const f of rHttp) currentReport.addFinding(f);
    if (Array.isArray(rFp)) for (const t of rFp) currentReport.addFinding({ name: 'Technology: ' + t.name, severity: 'info', category: t.category, detail: 'Detected via ' + t.source });

    renderResults(currentReport); showScanning(false);
    emptyStateDiv.classList.add('hidden'); resultsDiv.classList.remove('hidden'); exportJsonBtn.classList.remove('hidden');
  } catch (e) { showScanning(false); resultsDiv.classList.remove('hidden'); document.getElementById('vulns-list').innerHTML = '<div class="vuln-item severity-high"><div class="vuln-header"><span class="vuln-severity high">ERROR</span><span class="vuln-title">Scan Failed</span></div><div class="vuln-desc">' + esc(e.message) + '</div></div>'; }
}

async function scanHeaders(url) {
  try { const r = await fetch(url, { method: 'GET', mode: 'cors', credentials: 'omit' }); const h = {}; r.headers.forEach((v,k) => h[k]=v); return analyzeHeaders(h); } catch(e) { return { results: {}, raw: {} }; }
}

async function detectXSS() {
  const tabs = await new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, r));
  if (!tabs[0]?.id) return [];
  const res = await chrome.scripting.executeScript({ target: { tabId: tabs[0].id }, func: () => {
    const findings = [], body = document.body?.innerHTML || '';
    for (const [key, val] of new URLSearchParams(window.location.search)) { if (!val || val.length > 100) continue; if (/<script|on\w+\s*=|javascript:|<img\s+src/i.test(val)) findings.push({ name: 'XSS - Dangerous input (' + key + ')', severity: 'medium', param: key, detail: 'Input contains XSS-like pattern' }); }
    document.querySelectorAll('iframe[srcdoc], object[data]').forEach(el => { const v = el.getAttribute(el.tagName==='IFRAME'?'srcdoc':'data'); if (v && /<script|javascript:/i.test(v)) findings.push({ name: 'XSS - Embedded content', severity: 'high', detail: '<'+el.tagName.toLowerCase+'>' }); });
    return findings;
  }});
  return res?.[0]?.result || [];
}

async function detectSQLi() {
  const urlObj = new URL(currentURL);
  const params = Array.from(urlObj.searchParams.entries());
  if (params.length === 0) return [];
  const findings = [];
  for (const [key, val] of params.slice(0,10)) {
    if (!val || val.length > 50) continue;
    for (const payload of ["' OR '1'='1", "1' AND '1'='2"]) {
      const u = new URL(currentURL); u.searchParams.set(key, payload);
      try { const r = await fetch(u.toString(), { method: 'GET', mode: 'cors' }); const html = await r.text(); if (/SQL\s*syntax|MySQL.*error|ORA-\d|SqlException|Unclosed\s*quote|incorrect\s*syntax|You\s*have\s*an\s*error/i.test(html)) findings.push({ name: 'SQLi - Error Based ('+key+')', severity: 'critical', param: key, payload, detail: 'SQL error in response ('+r.status+')' }); } catch(e) {}
    }
  }
  return findings;
}

async function detectCORS() {
  const findings = [];
  try {
    const r1 = await fetch(currentURL, { method: 'GET', mode: 'cors', credentials: 'omit' });
    const acao = r1.headers.get('Access-Control-Allow-Origin');
    const acac = r1.headers.get('Access-Control-Allow-Credentials');
    if (acao === '*') findings.push({ name: 'CORS - Wildcard Allow-Origin', severity: 'high', detail: 'Access-Control-Allow-Origin: *' });
    if (acao && acao !== '*' && acac === 'true') findings.push({ name: 'CORS - Credentials with Dynamic Origin', severity: 'medium', detail: 'Allow-Origin: ' + acao + ' with credentials' });
  } catch(e) {}

  try {
    const r2 = await fetch(currentURL, { method: 'GET', mode: 'cors', credentials: 'omit', headers: { 'Origin': 'https://evil.com' } });
    if (r2.headers.get('Access-Control-Allow-Origin') === 'https://evil.com') findings.push({ name: 'CORS - Origin Reflection', severity: 'critical', detail: 'Reflected https://evil.com' });
  } catch(e) {}

  return findings;
}

async function detectSSRF() {
  const urlObj = new URL(currentURL);
  const params = Array.from(urlObj.searchParams.entries());
  const keys = ['url','redirect','target','path','src','ref'];
  const suspicious = params.filter(([k]) => keys.some(n => k.toLowerCase() === n));
  if (suspicious.length === 0) return [];
  const findings = [];
  for (const [key, val] of suspicious) {
    if (!val || val.length > 100) continue;
    const u = new URL(currentURL); u.searchParams.set(key, 'http://127.0.0.1:80');
    try { const r = await fetch(u.toString(), { method: 'GET', mode: 'cors', credentials: 'omit', redirect: 'manual' }); const loc = r.headers.get('location') || ''; if (/^https?:\/\/(127\.|localhost)/i.test(loc)) findings.push({ name: 'SSRF - Internal Redirect ('+key+')', severity: 'critical', param: key, detail: 'Redirects to '+loc }); } catch(e) {}
  }
  return findings;
}

async function detectHTTPMethods() {
  const findings = [];
  for (const method of ['TRACE','PUT','DELETE']) {
    try { const r = await fetch(currentURL, { method, mode: 'cors', credentials: 'omit' }); if (r.status !== 405 && r.status !== 501) findings.push({ name: 'HTTP Method - '+method+' Supported', severity: 'medium', detail: 'Status '+r.status }); } catch(e) {}
  }
  return findings;
}

async function detectFingerprint() {
  const tabs = await new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, r));
  if (!tabs[0]?.id) return [];
  const res = await chrome.scripting.executeScript({ target: { tabId: tabs[0].id }, func: () => {
    const techs = [], body = document.body?.innerHTML || '';
    if (window.jQuery) techs.push({ name: 'jQuery', category: 'Frontend', source: 'JS var' });
    if (window.React) techs.push({ name: 'React', category: 'Frontend', source: 'JS var' });
    if (window.Vue) techs.push({ name: 'Vue.js', category: 'Frontend', source: 'JS var' });
    if (window.angular) techs.push({ name: 'Angular', category: 'Frontend', source: 'JS var' });
    if (document.getElementById('__NEXT_DATA__')) techs.push({ name: 'Next.js', category: 'Framework', source: 'DOM' });
    if (body.includes('wp-content') || body.includes('wp-includes')) techs.push({ name: 'WordPress', category: 'CMS', source: 'DOM' });
    if (body.includes('woocommerce')) techs.push({ name: 'WooCommerce', category: 'E-commerce', source: 'DOM' });
    document.querySelectorAll('script[src]').forEach(s => { const src = s.src||''; if (src.includes('cloudflare')) techs.push({ name: 'Cloudflare', category: 'CDN', source: 'Script' }); });
    return techs;
  }});
  return res?.[0]?.result || [];
}

function renderResults(report) {
  const b = report.getBreakdown();
  document.getElementById('count-critical').textContent = b.critical;
  document.getElementById('count-high').textContent = b.high;
  document.getElementById('count-medium').textContent = b.medium;
  document.getElementById('count-low').textContent = b.low;
  document.getElementById('risk-summary').textContent = report.getRiskLevel();

  const vulnsDiv = document.getElementById('vulns-list');
  const sectionVulns = document.getElementById('section-vulns');
  const sevFindings = report.findings.filter(f => f.severity !== 'info' && !f.name.startsWith('Technology:'));

  if (sevFindings.length > 0) {
    sectionVulns.classList.remove('hidden');
    vulnsDiv.innerHTML = sevFindings.map(f => '<div class="vuln-item severity-'+f.severity+'"><div class="vuln-header"><span class="vuln-severity '+f.severity+'">'+f.severity+'</span><span class="vuln-title">'+esc(f.name)+'</span></div>' + (f.param ? '<div class="vuln-detail">Param: '+esc(f.param)+(f.payload?' \u2192 '+esc(f.payload):'')+'</div>':'') + '<div class="vuln-desc">'+esc(f.detail||'')+'</div>' + (f.remediation?'<div style="margin-top:2px;padding:3px 6px;background:#1a3a1a;border-radius:3px;color:#3fb950;font-size:10px;">Fix: '+esc(f.remediation)+'</div>':'') + '</div>').join('');
  } else { sectionVulns.classList.add('hidden'); }

  const techDiv = document.getElementById('tech-list');
  const techF = report.findings.filter(f => f.name.startsWith('Technology:'));
  techDiv.innerHTML = techF.length > 0 ? techF.map(f => '<span class="tech-tag">'+esc(f.name.replace('Technology: ',''))+'</span>').join('') : '<span style="color:#484f58;font-size:11px;">No technologies detected</span>';

  const sectionSSL = document.getElementById('section-ssl');
  const sslInfo = document.getElementById('ssl-info');
  if (currentURL?.startsWith('https://')) { sectionSSL.classList.remove('hidden'); sslInfo.innerHTML = '<div class="list-item pass"><span class="item-icon">\u2713</span><span class="item-content">Using HTTPS - secure</span></div>'; }
  else if (currentURL?.startsWith('http://')) { sectionSSL.classList.remove('hidden'); sslInfo.innerHTML = '<div class="list-item fail"><span class="item-icon">\u2717</span><span class="item-content">Using HTTP - unencrypted!</span></div>'; }
  else { sectionSSL.classList.add('hidden'); }
}

function getHeaderSeverity(n) { return { 'Strict-Transport-Security':'critical','Content-Security-Policy':'high','X-Frame-Options':'high','X-Content-Type-Options':'medium','Referrer-Policy':'medium' }[n] || 'info'; }
function showScanning(s) { if (s) { scanningStatus.classList.remove('hidden'); scanBtn.style.opacity='0.5'; scanBtn.disabled=true; } else { scanningStatus.classList.add('hidden'); scanBtn.style.opacity='1'; scanBtn.disabled=false; } }
function hideResults() { resultsDiv.classList.add('hidden'); emptyStateDiv.classList.add('hidden'); }
function esc(s) { return s ? document.createElement('div').textContent = s || '' : ''; }
