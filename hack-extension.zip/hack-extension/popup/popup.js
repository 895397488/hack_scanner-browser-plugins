// Hack Scanner Popup Logic — updated to use all enhanced modules

let currentReport = null, currentURL = '', mode = 'manual';

const scanBtn = document.getElementById('scan-btn');
const currentUrlEl = document.getElementById('current-url');
const resultsDiv = document.getElementById('results');
const emptyStateDiv = document.getElementById('empty-state');
const scanningStatus = document.getElementById('scanning-status');
const exportJsonBtn = document.getElementById('export-json');

document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.url?.startsWith('http')) { currentURL = tab.url; currentUrlEl.textContent = currentURL; }
  chrome.storage.local.get(['config'], (items) => {
    if (items.config?.autoScan) { mode = 'auto'; document.getElementById('mode-auto').checked = true; }
    else { mode = 'manual'; document.getElementById('mode-manual').checked = true; }
  });
  if (mode === 'auto' && currentURL) triggerScan();
});

document.querySelectorAll('input[name="mode"]').forEach(radio => {
  radio.addEventListener('change', (e) => { mode = e.target.value; chrome.storage.local.set({ config: { autoScan: mode === 'auto' } }); });
});

scanBtn.addEventListener('click', triggerScan);
exportJsonBtn.addEventListener('click', () => { if (currentReport) currentReport.downloadJSON(`hack_report_${new Date().toISOString().slice(0,10)}.json`); });

async function triggerScan() {
  if (!currentURL) return;
  showScanning(true); hideResults();
  try {
    // 1. HTTP headers analysis (includes sensitive header detection)
    const rH = await scanHeaders(currentURL);

    // 2. Sensitive data + OpenAPI discovery in page content
    const rSensitive = await detectSensitiveDataInPage(currentURL);

    // 3. XSS & SQLi (with actual payload testing)
    const rXssSql = await detectXSSAndSQLi();

    // 4. CORS detection
    const rCors = await detectCORS();

    // 5. SSRF detection
    const rSsrf = await detectSSRF();

    // 6. HTTP method checking (fixed: 404 != supported)
    const rHttp = await detectHTTPMethods();

    // 7. Comprehensive fingerprint + OpenAPI discovery
    const rFp = await detectFingerprint(rH.headers);

    // 8. Subdomain enumeration
    const rSubdomains = await enumerateSubdomains();

    currentReport = new ScanReport();
    currentReport.setTarget(currentURL);
    currentReport.setMode(mode);

    // Collect findings from all sources
    const allFindings = [];

    // Headers: missing security headers
    if (rH?.results) {
      for (const [n, info] of Object.entries(rH.results)) {
        if (!info.present && !['X-XSS-Protection'].includes(n)) {
          allFindings.push({ name: `Missing Header: ${n}`, severity: getHeaderSeverity(n), category: 'Security Headers', detail: info.issue || n + ' missing', remediation: 'Add "' + n + '" header' });
        }
      }
    }

    // Headers: sensitive headers (info-level findings)
    if (rH?.infoFindings) {
      for (const f of rH.infoFindings) allFindings.push(f);
    }

    // Sensitive data findings
    if (rSensitive?.findings) {
      for (const f of rSensitive.findings) allFindings.push(formatFinding(f, 'sensitive'));
    }
    // OpenAPI references from sensitive scan
    if (rSensitive?.openapi && rSensitive.openapi.length > 0) {
      for (const o of rSensitive.openapi) {
        allFindings.push({ name: `OpenAPI Reference: ${o.name}`, severity: 'info', category: 'API', detail: 'Found in page content' });
      }
    }

    // XSS + SQLi findings
    for (const f of rXssSql.findings) allFindings.push(formatFinding(f, 'xsssql'));

    // CORS findings
    for (const f of rCors) allFindings.push({ name: f.name, severity: f.severity, category: 'CORS', detail: f.detail, remediation: f.remediation });

    // SSRF findings
    for (const f of rSsrf) allFindings.push(formatFinding(f, 'ssrf'));

    // HTTP method findings
    for (const f of rHttp) allFindings.push(formatFinding(f, 'httpmethod'));

    // Technology fingerprint
    if (Array.isArray(rFp)) { for (const t of rFp) allFindings.push({ name: 'Technology: ' + t.name, severity: 'info', category: t.category || 'Technology', detail: 'Detected via ' + t.source }); }

    // OpenAPI findings
    if (rFp?.openapi) { for (const o of rFp.openapi) allFindings.push({ name: 'OpenAPI Reference: ' + o.name, severity: 'info', category: 'API', detail: 'Found in page content' }); }

    currentReport.findings = allFindings;
    renderResults(currentReport); showScanning(false);

    emptyStateDiv.classList.add('hidden'); resultsDiv.classList.remove('hidden'); exportJsonBtn.classList.remove('hidden');

    // Render subdomains if found
    renderSubdomains(rSubdomains, rH.headers || {});

  } catch (e) { showScanning(false); resultsDiv.classList.remove('hidden'); document.getElementById('vulns-list').innerHTML = '<div class="vuln-item severity-high"><div class="vuln-header"><span class="vuln-severity high">ERROR</span><span class="vuln-title">Scan Failed</span></div><div class="vuln-desc">' + esc(e.message) + '</div></div>'; }
}

async function scanHeaders(url) {
  try {
    const r = await fetch(url, { method: 'GET', mode: 'cors', credentials: 'omit', signal: AbortSignal.timeout(10000) });
    const h = {};
    r.headers.forEach((v,k) => h[k] = v);
    // Also store raw headers for display
    h._raw_presented = true;
    return { ...analyzeHeaders(h), headers: h };
  } catch(e) { return { results: {}, infoFindings: [], headers: {} }; }
}

async function detectSensitiveDataInPage(url) {
  try {
    // Use allorigins as CORS proxy to fetch page content
    const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
    const resp = await fetch(proxyUrl, { signal: AbortSignal.timeout(15000) });
    const content = await resp.text();

    // Scan for sensitive patterns
    const findings = [];
    const patterns = [
      { name: 'Email Address', pattern: /[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+/g, severity: 'low', cwe: 'CWE-200', cvss: 3.0, recommendation: '移除代码中的个人邮箱地址' },
      { name: 'Hardcoded IP (private)', pattern: /\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b/g, severity: 'medium', cwe: 'CWE-200', cvss: 5.3, recommendation: '移除配置文件中的内网IP暴露' },
      { name: 'JWT Token', pattern: /eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]+/g, severity: 'high', cwe: 'CWE-287', cvss: 7.5, recommendation: '不要在响应中返回完整JWT' },
      { name: 'AWS Access Key', pattern: /(?:A3T[A-Z0-9]|AKIA|AGPA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}/g, severity: 'critical', cwe: 'CWE-798', cvss: 9.1, recommendation: '立即轮换AWS凭证' },
      { name: 'GitHub Token', pattern: /ghp_[A-Za-z0-9]{36}/g, severity: 'critical', cwe: 'CWE-798', cvss: 9.1, recommendation: '立即撤销该令牌' },
      { name: 'Private Key', pattern: /-----BEGIN\s+(RSA|DSA|EC|OPENSSH)\s+PRIVATE\s+KEY-----/g, severity: 'critical', cwe: 'CWE-312', cvss: 9.1, recommendation: '立即轮换密钥' },
    ];

    for (const p of patterns) {
      const matches = [...content.matchAll(p.pattern)];
      if (matches.length > 0) {
        const uniqueMatches = [...new Set(matches.map(m => m[0].substring(0, 50)))].slice(0, 3);
        findings.push({
          id: `SENSITIVE_${p.name.replace(/\s+/g, '_')}`,
          severity: p.severity,
          title: `发现 ${p.name}`,
          description: `在页面内容中检测到匹配 ${p.name} 的模式`,
          url: url, evidence: uniqueMatches.join(', '),
          recommendation: p.recommendation, cwe: p.cwe, cvss: p.cvss, params: {},
        });
      }
    }

    // Check for DVCS / config leak references
    const dvcsPatterns = ['.git/config', '.env', 'crossdomain.xml', '.DS_Store'];
    for (const dp of dvcsPatterns) {
      if (content.includes(dp)) {
        findings.push({
          id: `DVCS_${dp.replace(/\./g, '_').toUpperCase()}`,
          severity: 'medium', title: `发现 ${dp} 引用`,
          description: `页面中包含 ${dp} 的引用`, url: url, evidence: `${dp}`,
          recommendation: '确保 .git、.env 等敏感文件不被公开访问', cwe: 'CWE-352', cvss: 5.3, params: {},
        });
      }
    }

    // Check for OpenAPI/Swagger references
    const openapiRefs = [];
    const openapiSigs = ['swagger.json','openapi.json','swagger.yml','openapi.yaml','swagger-ui.html','/docs','/redoc','/api-docs','/graphql','graphiql'];
    for (const sig of openapiSigs) {
      if (content.includes(sig)) openapiRefs.push(sig);
    }

    // Also check DOM for additional references
    const domContent = typeof document !== 'undefined' ? document.body?.innerHTML || '' : '';
    for (const sig of openapiSigs) {
      if (domContent.includes(sig) && !openapiRefs.includes(sig)) openapiRefs.push(sig);
    }

    return { findings, openapi: openapiRefs.length > 0 ? openapiRefs.map(r => ({ name: r })) : [], domContent };
  } catch(e) {
    // CORS proxy unavailable — fall back to DOM-only scan
    if (typeof document !== 'undefined' && document.body) {
      return scanDOMForSensitive(document.body.innerHTML);
    }
    return { findings: [], openapi: [] };
  }
}

function scanDOMForSensitive(domContent) {
  const findings = [];
  try {
    const patterns = [
      { name: 'Email Address', pattern: /[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+/g, severity: 'low', cwe: 'CWE-200', cvss: 3.0 },
      { name: 'Hardcoded IP (private)', pattern: /\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b/g, severity: 'medium', cwe: 'CWE-200', cvss: 5.3 },
      { name: 'JWT Token', pattern: /eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]+/g, severity: 'high', cwe: 'CWE-287', cvss: 7.5 },
    ];
    for (const p of patterns) {
      const matches = [...(domContent || '').matchAll(p.pattern)];
      if (matches.length > 0) {
        const uniqueMatches = [...new Set(matches.map(m => m[0].substring(0, 50)))].slice(0, 3);
        findings.push({ id: `SENSITIVE_${p.name.replace(/\s+/g, '_')}`, severity: p.severity, title: `发现 ${p.name} (DOM)`, url: currentURL, evidence: uniqueMatches.join(', '), recommendation: '检查代码中敏感信息', cwe: p.cwe, cvss: p.cvss, params: {} });
      }
    }
  } catch {}
  return { findings, openapi: [] };
}

async function detectXSSAndSQLi() {
  const urlObj = new URL(currentURL);
  const params = Array.from(urlObj.searchParams.entries());
  if (params.length === 0) return { findings: [], openapi: [] };

  // SQLi detection
  let sqlFindings = [];
  try {
    for (const [key, value] of params) {
      if (!value || value.length > 50) continue;
      const payloads = ["' OR '1'='1", "' OR 1=1 --", "\" OR \"1\"=\"1"];
      for (const payload of payloads) {
        try {
          const testUrl = new URL(currentURL);
          testUrl.searchParams.set(key, payload);
          const resp = await fetch(testUrl.toString(), { redirect: 'follow', signal: AbortSignal.timeout(8000) });
          const html = await resp.text();

          // Check for SQL error messages
          if (/SQL\s*syntax.*?MySQL|MySQL.*?error|ORA-\d{5}|PostgreSQL.*?error|SqlException|Unclosed\s*quote|incorrect\s*syntax|You\s*have\s*an\s*error/i.test(html)) {
            sqlFindings.push({ id: `SQLI_ERROR_${key}`, severity: 'critical', title: `SQL注入 - 错误回显 (${key})`, param: key, payload, detail: 'SQL error reflected in response', recommendation: '使用参数化查询', cwe: 'CWE-89', cvss: 9.8 });
            break;
          }
        } catch {}
      }
    }

    // XSS detection via payload testing
    let xssFindings = [];
    for (const [key, value] of params) {
      if (!value || value.length > 100) continue;
      const payloads = ['<script>alert(1)</script>', '<img src=x onerror=alert(1)>', '<svg/onload=alert(1)>'];
      for (const payload of payloads) {
        try {
          const testUrl = new URL(currentURL);
          testUrl.searchParams.set(key, payload);
          const resp = await fetch(testUrl.toString(), { signal: AbortSignal.timeout(8000) });
          const html = await resp.text();

          const escaped = escapeRegex(payload);
          if (new RegExp(escaped, 'i').test(html)) {
            xssFindings.push({ id: `XSS_${key}`, severity: 'high', title: `反射型XSS (${key})`, param: key, payload, detail: 'Payload reflected without encoding — potential XSS', recommendation: '实施输出编码和CSP', cwe: 'CWE-79', cvss: 6.1 });
            break;
          }
        } catch {}
      }
    }

    return { findings: [...sqlFindings, ...xssFindings], openapi: [] };
  } catch(e) { return { findings: [], openapi: [] }; }
}

async function detectCORS() {
  const findings = [];
  try {
    const r1 = await fetch(currentURL, { method: 'GET', mode: 'cors', credentials: 'omit', signal: AbortSignal.timeout(8000) });
    const acao = r1.headers.get('Access-Control-Allow-Origin');
    const acac = r1.headers.get('Access-Control-Allow-Credentials');

    if (acao === '*') {
      findings.push({ name: 'CORS - Wildcard Allow-Origin', severity: 'high', detail: 'Access-Control-Allow-Origin: *', remediation: 'Restrict Access-Control-Allow-Origin to trusted domains only' });
    }

    // Test evil.com origin reflection
    try {
      const r2 = await fetch(currentURL, { method: 'GET', mode: 'cors', credentials: 'omit', headers: { 'Origin': 'https://evil.com' }, signal: AbortSignal.timeout(8000) });
      if (r2.headers.get('Access-Control-Allow-Origin') === 'https://evil.com') {
        findings.push({ name: 'CORS - Origin Reflection', severity: 'critical', detail: 'Reflected https://evil.com — data exfiltration possible', remediation: 'Validate Origin against explicit whitelist' });
      }
    } catch {}

    if (acao && acao !== '*' && acac === 'true') {
      findings.push({ name: 'CORS - Credentials with Dynamic Origin', severity: 'medium', detail: 'Allow-Origin: ' + acao + ' with credentials', remediation: 'Do not use Access-Control-Allow-Credentials with dynamically reflected origins' });
    }
  } catch(e) {}
  return findings;
}

async function detectSSRF() {
  const urlObj = new URL(currentURL);
  const params = Array.from(urlObj.searchParams.entries());
  const keys = ['url','redirect','target','path','src','ref'];
  const suspicious = params.filter(([k]) => keys.some(n => k.toLowerCase().includes(n)));
  if (suspicious.length === 0) return [];

  const findings = [];
  for (const [key, val] of suspicious) {
    try {
      const u = new URL(currentURL); u.searchParams.set(key, 'http://127.0.0.1:80');
      const r = await fetch(u.toString(), { method: 'GET', mode: 'cors', credentials: 'omit', redirect: 'manual', signal: AbortSignal.timeout(8000) });
      const loc = r.headers.get('location') || '';
      if (/^https?:\/\/(127\.|localhost)/i.test(loc)) findings.push({ id: `SSRF_${key}`, severity: 'critical', title: `SSRF - 内部重定向 (${key})`, param: key, detail: 'Redirects to ' + loc, recommendation: 'Validate and whitelist allowed URLs', cwe: 'CWE-918', cvss: 9.8 });
    } catch {}
  }
  return findings;
}

async function detectHTTPMethods() {
  const findings = [];
  for (const method of ['TRACE','PUT','DELETE']) {
    try {
      const r = await fetch(currentURL, { method, mode: 'cors', credentials: 'omit', signal: AbortSignal.timeout(8000) });
      // Only report if server actually responds with non-error status (2xx/3xx)
      if (r.status >= 200 && r.status < 400) {
        findings.push({ id: `HTTP_${method}`, severity: 'medium', title: `HTTP方法 - ${method} 支持`, param: method, detail: `${method} method allowed (${r.status})`, recommendation: 'Restrict HTTP methods to GET/POST only if possible', cwe: 'CWE-693', cvss: 4.3 });
      }
    } catch {}
  }
  return findings;
}

async function detectFingerprint(headers) {
  const tabs = await new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, r));
  let techs = [];
  if (tabs[0]?.id) {
    const res = await chrome.scripting.executeScript({ target: { tabId: tabs[0].id }, func: () => {
      const techs = [], body = document.body?.innerHTML || '';
      // Framework detection
      if (window.jQuery) techs.push({ name: 'jQuery', category: 'Library', source: 'JS var' });
      if (window.React) techs.push({ name: 'React', category: 'Frontend', source: 'JS var' });
      if (window.Vue) techs.push({ name: 'Vue.js', category: 'Frontend', source: 'JS var' });
      if (window.angular) techs.push({ name: 'Angular', category: 'Frontend', source: 'JS var' });
      if (document.getElementById('__NEXT_DATA__')) techs.push({ name: 'Next.js', category: 'Framework', source: 'DOM' });
      if (body.includes('wp-content') || body.includes('wp-includes')) techs.push({ name: 'WordPress', category: 'CMS', source: 'DOM' });
      if (body.includes('woocommerce')) techs.push({ name: 'WooCommerce', category: 'E-commerce', source: 'DOM' });
      // CDNs from scripts
      document.querySelectorAll('script[src]').forEach(s => { const src = s.src||''; if (src.includes('cloudflare')) techs.push({ name: 'Cloudflare', category: 'CDN', source: 'Script' }); if (src.includes('amazonaws.com') || src.includes('cloudfront.net')) techs.push({ name: 'AWS CloudFront', category: 'CDN', source: 'Script' }); if (src.includes('cdn.shopify')) techs.push({ name: 'Shopify', category: 'E-commerce', source: 'Script' }); if (src.includes('google-analytics') || src.includes('googletagmanager')) techs.push({ name: 'Google Analytics', category: 'Analytics', source: 'Script' }); });
      // Bootstrap/Tailwind from stylesheets
      document.querySelectorAll('link[rel="stylesheet"]').forEach(s => { const href = s.href||''; if (href.includes('bootstrap') || href.includes('/bootstrap/')) techs.push({ name: 'Bootstrap', category: 'CSS', source: 'Stylesheet' }); if (href.includes('tailwind')) techs.push({ name: 'Tailwind CSS', category: 'CSS', source: 'Stylesheet' }); });
      return techs;
    }});
    techs = res?.[0]?.result || [];
  }

  // Server detection from headers
  if (headers) {
    const hKeys = {}; for (const k of Object.keys(headers)) hKeys[k.toLowerCase()] = headers[k];
    if (hKeys['server']) {
      const srv = hKeys['server'];
      if (/nginx/i.test(srv)) techs.push({ name: 'Nginx', category: 'Server', source: 'Header' });
      else if (/apache/i.test(srv)) techs.push({ name: 'Apache', category: 'Server', source: 'Header' });
      else if (/iis|msws/i.test(srv)) techs.push({ name: 'IIS', category: 'Server', source: 'Header' });
      else techs.push({ name: `Server: ${srv}`, category: 'Server', source: 'Header' });
    }
  }

  // Cookie-based backend detection
  if (document.cookie) {
    if (document.cookie.includes('laravel_session')) techs.push({ name: 'Laravel', category: 'Backend', source: 'Cookie' });
    if (/_[a-z0-9]+_session_id=/.test(document.cookie)) techs.push({ name: 'Rails', category: 'Backend', source: 'Cookie' });
  }

  return { techs, openapi: [] }; // openapi populated from sensitive data scan
}

async function enumerateSubdomains() {
  try {
    const urlObj = new URL(currentURL);
    const hostname = urlObj.hostname;
    const parts = hostname.split('.');
    let baseDomain;
    if (parts.length <= 2) baseDomain = hostname;
    else {
      const sld = parts[parts.length - 2];
      const tld = parts[parts.length - 1];
      baseDomain = `${sld}.${tld}`;
    }

    // Use CertSpotter API (CORS-friendly, no auth needed)
    const resp = await fetch(`https://api.certspotter.com/v1/issuances?domain=${baseDomain}&include_subdomains=true&expand=dns_names`, { signal: AbortSignal.timeout(20000) });
    const data = await resp.json();

    const subdomains = new Set();
    for (const entry of data) {
      for (const domain of (entry.dns_names || [])) {
        if (domain !== hostname && domain.includes(baseDomain)) {
          subdomains.add(domain.replace(/\*/g, 'any'));
        }
      }
    }

    // Also try crt.sh as fallback
    if (subdomains.size < 5) {
      try {
        const resp2 = await fetch(`https://crt.sh/?q=%25.${baseDomain}&output=json`, { signal: AbortSignal.timeout(30000) });
        const data2 = await resp2.json();
        for (const entry of data2) {
          for (const domain of (entry.name_value || '').split('\n')) {
            if (domain !== hostname && domain.includes(baseDomain)) subdomains.add(domain.replace(/\*/g, 'any'));
          }
        }
      } catch {}
    }

    return sortedArray(subdomains);
  } catch(e) {
    console.log('[HackScanner] Subdomain enumeration failed:', e.message);
    return [];
  }
}

function renderSubdomains(subdomains, headers) {
  const section = document.getElementById('section-subdomains');
  const list = document.getElementById('subdomains-list');

  if (subdomains.length === 0) { section.classList.add('hidden'); return; }

  section.classList.remove('hidden');
  list.innerHTML = subdomains.map(s => `<span class="tech-tag" style="cursor:pointer;" title="${s}">${esc(s)}</span>`).join('');

  // Click to scan a subdomain
  list.querySelectorAll('.tech-tag').forEach(tag => {
    tag.addEventListener('click', async () => {
      const host = tag.textContent.replace(/^any\./, '*.');
      try { await chrome.tabs.create({ url: `https://${host}` }); } catch {}
    });
  });
}

function formatFinding(f, type) {
  if (f.id && f.severity && f.title && f.description) {
    return { id: f.id, name: f.title, severity: f.severity, detail: f.description, recommendation: f.recommendation, param: f.params?.header || '', cwe: f.cwe, cvss: f.cvss, payload: f.evidence };
  }
  return f;
}

function renderResults(report) {
  const b = report.getBreakdown();
  document.getElementById('count-critical').textContent = b.critical;
  document.getElementById('count-high').textContent = b.high;
  document.getElementById('count-medium').textContent = b.medium;
  document.getElementById('count-low').textContent = b.low;
  document.getElementById('risk-summary').textContent = report.getRiskLevel();

  // Separate findings by category
  const vulnFindings = report.findings.filter(f => f.severity !== 'info' && !f.name?.startsWith('Technology:'));
  const techFindings = report.findings.filter(f => f.name?.startsWith('Technology:'));
  const openapiFindings = report.findings.filter(f => f.name?.startsWith('OpenAPI'));
  const sensitiveFindings = report.findings.filter(f => f.id && (f.id.startsWith('SENSITIVE_') || f.id.startsWith('DVCS_')));

  // Render vulnerabilities section
  const vulnsDiv = document.getElementById('vulns-list');
  const sectionVulns = document.getElementById('section-vulns');
  if (vulnFindings.length > 0) {
    sectionVulns.classList.remove('hidden');
    vulnsDiv.innerHTML = vulnFindings.map(f => `<div class="vuln-item severity-${f.severity}"><div class="vuln-header"><span class="vuln-severity ${f.severity}">${f.severity}</span><span class="vuln-title">${esc(f.name || f.title || 'Unknown')}</span></div>${f.param ? '<div class="vuln-detail">Param: ' + esc(f.param) + (f.payload ? ' \u2192 ' + esc(f.payload) : '') + '</div>' : ''}<div class="vuln-desc">${esc(f.detail || f.description || '')}</div>${f.remediation ? '<div style="margin-top:2px;padding:3px 6px;background:#1a3a1a;border-radius:3px;color:#3fb950;font-size:10px;">Fix: ' + esc(f.remediation) + '</div>' : f.recommendation ? '<div style="margin-top:2px;padding:3px 6px;background:#1a3a1a;border-radius:3px;color:#3fb950;font-size:10px;">Recommendation: ' + esc(f.recommendation) + '</div>' : ''}</div>`).join('');
  } else { sectionVulns.classList.add('hidden'); }

  // Render OpenAPI section if found
  const openapiDiv = document.getElementById('paths-list');
  const sectionPaths = document.getElementById('section-paths');
  if (openapiFindings.length > 0) {
    sectionPaths.classList.remove('hidden');
    openapiDiv.innerHTML = openapiFindings.map(f => `<span class="tech-tag" style="background:#1c3a5e;">${esc(f.name)}</span>`).join('') + '<div style="color:#8b949e;font-size:10px;margin-top:4px;">OpenAPI/Swagger 文档引用 — 请手动验证是否公开可访问</div>';
  } else { sectionPaths.classList.add('hidden'); }

  // Render sensitive data section
  const sensitiveSection = document.getElementById('section-sensitive');
  const sensitiveDiv = document.getElementById('sensitive-list');
  if (sensitiveFindings.length > 0) {
    sensitiveSection.classList.remove('hidden');
    sensitiveDiv.innerHTML = '<div class="list-item warn"><strong>敏感信息:</strong></div>' + sensitiveFindings.map(f => `<div class="vuln-item severity-${f.severity}" style="margin-top:4px;"><div class="vuln-header"><span class="vuln-severity ${f.severity}">${f.severity}</span><span class="vuln-title">${esc(f.title || f.name || 'Sensitive Data')}</span></div><div class="vuln-desc">${esc(f.description || f.detail || f.evidence || '')}</div>${f.recommendation ? '<div style="margin-top:2px;padding:3px 6px;background:#1a3a1a;border-radius:3px;color:#3fb950;font-size:10px;">Fix: ' + esc(f.recommendation) + '</div>' : ''}</div>`).join('');
  } else { sensitiveSection.classList.add('hidden'); }

  // Render tech stack
  const sectionTech = document.getElementById('section-tech');
  const techDiv = document.getElementById('tech-list');
  if (techFindings.length > 0) {
    sectionTech.classList.remove('hidden');
    techDiv.innerHTML = techFindings.map(f => `<span class="tech-tag">${esc(f.name.replace('Technology: ',''))}</span>`).join('');
  } else {
    sectionTech.classList.add('hidden');
  }

  // SSL info
  const sectionSSL = document.getElementById('section-ssl');
  const sslInfo = document.getElementById('ssl-info');
  if (currentURL?.startsWith('https://')) { sectionSSL.classList.remove('hidden'); sslInfo.innerHTML = '<div class="list-item pass"><span class="item-icon">\u2713</span><span class="item-content">Using HTTPS - secure</span></div>'; }
  else if (currentURL?.startsWith('http://')) { sectionSSL.classList.remove('hidden'); sslInfo.innerHTML = '<div class="list-item fail"><span class="item-icon">\u2717</span><span class="item-content">Using HTTP - unencrypted!</span></div>'; }
  else { sectionSSL.classList.add('hidden'); }

  // Render headers list
  renderHeadersList();
}

function renderHeadersList() {
  // Re-fetch headers for display (we don't store them in report, so fetch again)
  if (!currentURL) return;
  fetch(currentURL, { method: 'GET', mode: 'cors', credentials: 'omit' }).then(r => {
    const h = {}; r.headers.forEach((v,k) => h[k] = v);
    const div = document.getElementById('headers-list');
    const sections = [
      { title: '关键安全头 (Critical)', keys: ['Content-Security-Policy','Strict-Transport-Security','X-Frame-Options'] },
      { title: '重要安全头 (Important)', keys: ['X-Content-Type-Options','Referrer-Policy','Cross-Origin-Opener-Policy','Permissions-Policy','Cross-Origin-Resource-Policy','Cross-Origin-Embedder-Policy'] },
      { title: '可选安全头 (Optional)', keys: ['X-XSS-Protection','Feature-Policy','Clear-Site-Data'] },
      { title: 'Server 信息', keys: ['Server','X-Powered-By'] },
    ];

    let html = '';
    for (const section of sections) {
      const presentHeaders = section.keys.filter(k => k.toLowerCase() in Object.fromEntries(Object.entries(h).map(([k,v])=>[k.toLowerCase(),v])));
      // Use a different approach: get values from the actual response headers
      html += `<div style="margin:8px 0;"><strong style="color:#e6edf3;font-size:11px;">${section.title}</strong><br>`;
      section.keys.forEach(key => {
        const val = h[key];
        if (val) html += `<div class="list-item pass"><span class="item-icon">\u2713</span><span class="item-content">${esc(key)}: <code style="color:#79c0ff;">${esc(val.substring(0,80))}</code></span></div>`;
        else html += `<div class="list-item fail"><span class="item-icon">\u2717</span><span class="item-content">${esc(key)}: <span style="color:#f85149;">not set</span></span></div>`;
      });
      html += '</div>';
    }
    div.innerHTML = html;
  }).catch(() => {});
}

function getHeaderSeverity(n) { return { 'Strict-Transport-Security':'medium','Content-Security-Policy':'medium','X-Frame-Options':'medium','Cross-Origin-Opener-Policy':'medium','X-Content-Type-Options':'medium','Referrer-Policy':'low','Permissions-Policy':'low','Cross-Origin-Resource-Policy':'low','Cross-Origin-Embedder-Policy':'low','Feature-Policy':'low','Clear-Site-Data':'low' }[n] || 'info'; }
function showScanning(s) { if (s) { scanningStatus.classList.remove('hidden'); scanBtn.style.opacity='0.5'; scanBtn.disabled=true; } else { scanningStatus.classList.add('hidden'); scanBtn.style.opacity='1'; scanBtn.disabled=false; } }
function hideResults() { resultsDiv.classList.add('hidden'); emptyStateDiv.classList.add('hidden'); document.getElementById('section-subdomains').classList.add('hidden'); document.getElementById('section-paths').classList.add('hidden'); }
function esc(s) { return s ? document.createElement('div').textContent = s || '' : ''; }
function escapeRegex(str) { return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
