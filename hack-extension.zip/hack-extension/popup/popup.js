// Hack Scanner Popup Logic
// All scanning runs directly in the popup — no messaging dependency

let currentReport = null;
let currentURL = '';
let mode = 'manual';

const scanBtn = document.getElementById('scan-btn');
const currentUrlEl = document.getElementById('current-url');
const resultsDiv = document.getElementById('results');
const emptyStateDiv = document.getElementById('empty-state');
const scanningStatus = document.getElementById('scanning-status');
const exportJsonBtn = document.getElementById('export-json');

document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.url && tab.url.startsWith('http')) {
    currentURL = tab.url;
    currentUrlEl.textContent = currentURL;
  }

  chrome.storage.local.get(['config'], (items) => {
    if (items.config?.autoScan) { mode = 'auto'; document.getElementById('mode-auto').checked = true; }
    else { mode = 'manual'; document.getElementById('mode-manual').checked = true; }
  });

  if (mode === 'auto' && currentURL) triggerScan();
});

document.querySelectorAll('input[name="mode"]').forEach(radio => {
  radio.addEventListener('change', (e) => {
    mode = e.target.value;
    chrome.storage.local.set({ config: { autoScan: mode === 'auto' } });
  });
});

scanBtn.addEventListener('click', triggerScan);
exportJsonBtn.addEventListener('click', () => {
  if (currentReport) currentReport.downloadJSON(`hack_report_${new Date().toISOString().slice(0,10)}.json`);
});

// ==================== MAIN SCAN ====================

async function triggerScan() {
  if (!currentURL) return;

  showScanning(true);
  hideResults();

  try {
    const [r_headers, r_xss, r_sqli, r_cors, r_ssrf, r_httpmethod, r_fingerprint] = await Promise.allSettled([
      scanHeaders(currentURL),
      detectXSS(),
      detectSQLi(),
      detectCORS(),
      detectSSRF(),
      detectHTTPMethods(),
      detectFingerprint(),
    ]);

    currentReport = new ScanReport();
    currentReport.setTarget(currentURL);
    currentReport.setMode(mode);

    // Headers
    const headersData = r_headers.status === 'fulfilled' ? r_headers.value : null;
    if (headersData?.results) {
      for (const [name, info] of Object.entries(headersData.results)) {
        if (!info.present) {
          currentReport.addFinding({ name: `Missing Header: ${name}`, severity: getHeaderSeverity(name), detail: info.issue || `${name} missing`, remediation: `Add "${name}" header with a secure policy` });
        }
      }
    }

    // XSS
    if (r_xss.status === 'fulfilled' && r_xss.value) {
      for (const f of r_xss.value) currentReport.addFinding(f);
    }

    // SQLi
    if (r_sqli.status === 'fulfilled' && r_sqli.value) {
      for (const f of r_sqli.value) currentReport.addFinding(f);
    }

    // CORS
    if (r_cors.status === 'fulfilled' && r_cors.value) {
      for (const f of r_cors.value) currentReport.addFinding(f);
    }

    // SSRF
    if (r_ssrf.status === 'fulfilled' && r_ssrf.value) {
      for (const f of r_ssrf.value) currentReport.addFinding(f);
    }

    // HTTP methods
    if (r_httpmethod.status === 'fulfilled' && r_httpmethod.value) {
      for (const f of r_httpmethod.value) currentReport.addFinding(f);
    }

    // Fingerprint
    const fpData = r_fingerprint.status === 'fulfilled' ? r_fingerprint.value : null;
    if (fpData) {
      for (const tech of fpData) {
        currentReport.addFinding({ name: `Technology: ${tech.name}`, severity: 'info', category: tech.category, detail: `Detected via ${tech.source}` });
      }
    }

    renderResults(currentReport);
    showScanning(false);
    emptyStateDiv.classList.add('hidden');
    resultsDiv.classList.remove('hidden');
    exportJsonBtn.classList.remove('hidden');

  } catch (e) {
    console.error('[HackScanner] Scan error:', e);
    showScanning(false);
    renderError(e.message);
  }
}

// ==================== DETECTION FUNCTIONS ====================

function scanHeaders(url) {
  return fetch(url, { method: 'GET', mode: 'cors', credentials: 'omit' })
    .then(resp => {
      const h = {};
      resp.headers.forEach((v, k) => h[k] = v);
      return analyzeHeaders(h);
    })
    .catch(() => ({ results: {}, raw: {} }));
}

function detectXSS() {
  // Check DOM for reflected XSS indicators
  const body = document.body?.innerHTML || '';
  const params = new URLSearchParams(window.location.search);
  const findings = [];

  for (const [key, val] of params) {
    if (!val || val.length > 100) continue;
    // Check if param value is reflected unencoded in the page
    if (/<script|on\w+\s*=|javascript:|<img\s+src|<svg/i.test(val)) {
      findings.push({ name: `XSS - Dangerous input (${key})`, severity: 'medium', param: key, detail: `Input contains XSS-like pattern`, remediation: 'Validate and sanitize user input server-side' });
    }
  }

  // Check for template injection in page content
  if (body.includes('{{') || body.includes('<%')) {
    findings.push({ name: 'XSS - Template injection indicators', severity: 'medium', detail: 'Template syntax found in page — potential SSRF or RCE vector' });
  }

  // Check iframe srcdoc / object data for XSS vectors
  document.querySelectorAll('iframe[srcdoc], object[data]').forEach(el => {
    const val = el.getAttribute(el.tagName === 'IFRAME' ? 'srcdoc' : 'data');
    if (val && /<script|javascript:|on\w+\s*=/i.test(val)) {
      findings.push({ name: 'XSS - Dangerous embedded content', severity: 'high', param: `[${el.tagName}] src/data`, detail: 'Dangerous pattern in embedded content' });
    }
  });

  return Promise.resolve(findings);
}

function detectSQLi() {
  return new Promise((resolve) => {
    const urlObj = new URL(currentURL);
    const params = Array.from(urlObj.searchParams.entries());
    const findings = [];

    if (params.length === 0) { resolve([]); return; }

    const payloads = ["' OR '1'='1", "1' AND '1'='2"];

    // Run SQLi tests sequentially to avoid race conditions
    async function runTests() {
      for (const [key, val] of params.slice(0, 10)) {
        if (!val || val.length > 50) continue;

        for (const payload of payloads) {
          const testUrl = new URL(currentURL);
          testUrl.searchParams.set(key, payload);

          try {
            const resp = await fetch(testUrl.toString(), { method: 'GET', mode: 'cors', credentials: 'omit' });
            const html = await resp.text();

            if (/SQL\s*syntax|MySQL.*error|ORA-\d|PostgreSQL|SqlException|mysqli.*error|PDO.*sql|Unclosed\s*quote|incorrect\s*syntax|You\s*have\s*an\s*error/i.test(html)) {
              findings.push({ name: `SQLi - Error Based (${key})`, severity: 'critical', param: key, payload, detail: `SQL error reflected in response (${resp.status})`, remediation: 'Use parameterized queries' });
            }
          } catch (e) {}
        }
      }
      resolve(findings);
    }

    runTests();
  });
}

function detectCORS() {
  return new Promise((resolve) => {
    const findings = [];

    fetch(currentURL, { method: 'GET', mode: 'cors', credentials: 'omit' })
      .then(resp => {
        const acao = resp.headers.get('Access-Control-Allow-Origin');
        const acac = resp.headers.get('Access-Control-Allow-Credentials');

        if (acao === '*') findings.push({ name: 'CORS - Wildcard Allow-Origin', severity: 'high', detail: 'Access-Control-Allow-Origin: *' });
        if (acao && acao !== '*' && acac === 'true') findings.push({ name: 'CORS - Credentials with Dynamic Origin', severity: 'medium', detail: `Allow-Origin: ${acao} with credentials` });

        // Test origin reflection
        return testOriginReflection(currentURL, findings);
      })
      .catch(() => resolve(findings));
  });
}

function testOriginReflection(url, findings) {
  return new Promise((resolve) => {
    fetch(url, { method: 'GET', mode: 'cors', credentials: 'omit', headers: { 'Origin': 'https://evil.com' } })
      .then(resp => {
        if (resp.headers.get('Access-Control-Allow-Origin') === 'https://evil.com') {
          findings.push({ name: 'CORS - Origin Reflection', severity: 'critical', detail: `Reflected origin: https://evil.com` });
        }
      })
      .catch(() => {})
      .finally(() => resolve(findings));
  });
}

function detectSSRF() {
  return new Promise((resolve) => {
    const findings = [];
    const urlObj = new URL(currentURL);
    const params = Array.from(urlObj.searchParams.entries());
    const ssrfParamNames = ['url', 'redirect', 'target', 'path', 'src', 'ref'];
    const suspicious = params.filter(([k]) => ssrfParamNames.some(n => k.toLowerCase() === n));

    if (suspicious.length === 0) { resolve([]); return; }

    async function testParams() {
      for (const [key, val] of suspicious) {
        if (!val || val.length > 100) continue;
        const testUrl = new URL(currentURL);
        testUrl.searchParams.set(key, 'http://127.0.0.1:80');

        try {
          const resp = await fetch(testUrl.toString(), { method: 'GET', mode: 'cors', credentials: 'omit', redirect: 'manual' });
          const loc = resp.headers.get('location') || '';
          if (/^https?:\/\/(127\.|localhost)/i.test(loc)) {
            findings.push({ name: `SSRF - Internal Redirect (${key})`, severity: 'critical', param: key, detail: `Redirects to ${loc}`, remediation: 'Whitelist allowed URLs on server side' });
          }
        } catch (e) {}
      }
      resolve(findings);
    }

    testParams();
  });
}

function detectHTTPMethods() {
  return new Promise((resolve) => {
    const findings = [];
    ['TRACE', 'PUT', 'DELETE'].forEach(method => {
      fetch(currentURL, { method, mode: 'cors', credentials: 'omit' })
        .then(resp => {
          if (resp.status !== 405 && resp.status !== 501) {
            findings.push({ name: `HTTP Method - ${method} Supported`, severity: 'medium', detail: `Returns status ${resp.status}`, remediation: 'Restrict HTTP methods to GET/POST' });
          }
        })
        .catch(() => {});
    });
    setTimeout(() => resolve(findings), 3000);
  });
}

function detectFingerprint() {
  return chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0] || !tabs[0].id) return [];

    return new Promise((resolve) => {
      chrome.scripting.executeScript(
        { target: { tabId: tabs[0].id }, files: ['lib/fingerprint.js'] },
        () => {
          if (chrome.runtime.lastError) { resolve([]); return; }
          chrome.tabs.sendMessage(tabs[0].id, { type: 'get-fingerprint' }, (resp) => {
            resolve(resp?.techs || []);
          });
        }
      );
    });
  });
}

// ==================== UI HELPERS ====================

function renderResults(report) {
  const b = report.getBreakdown();
  document.getElementById('count-critical').textContent = b.critical;
  document.getElementById('count-high').textContent = b.high;
  document.getElementById('count-medium').textContent = b.medium;
  document.getElementById('count-low').textContent = b.low;
  document.getElementById('risk-summary').textContent = report.getRiskLevel();

  const vulnsDiv = document.getElementById('vulns-list');
  const sectionVulns = document.getElementById('section-vulns');
  const sevFindings = report.findings.filter(f => f.severity !== 'info' && !f.name.startsWith('Technology:'));

  if (sevFindings.length > 0) {
    sectionVulns.classList.remove('hidden');
    vulnsDiv.innerHTML = sevFindings.map(f => `
      <div class="vuln-item severity-${f.severity}">
        <div class="vuln-header"><span class="vuln-severity ${f.severity}">${f.severity}</span><span class="vuln-title">${esc(f.name)}</span></div>
        ${f.param ? `<div class="vuln-detail">Param: ${esc(f.param)}${f.payload ? ' → ' + esc(f.payload) : ''}</div>` : ''}
        <div class="vuln-desc">${esc(f.detail || f.evidence || '')}</div>
        ${f.remediation ? `<div style="margin-top:2px;padding:3px 6px;background:#1a3a1a;border-radius:3px;color:#3fb950;font-size:10px;">Fix: ${esc(f.remediation)}</div>` : ''}
      </div>
    `).join('');
  } else {
    sectionVulns.classList.add('hidden');
  }

  const techDiv = document.getElementById('tech-list');
  const techFindings = report.findings.filter(f => f.name.startsWith('Technology:'));
  techDiv.innerHTML = techFindings.length > 0
    ? techFindings.map(f => `<span class="tech-tag">${esc(f.name.replace('Technology: ', ''))}</span>`).join('')
    : '<span style="color:#484f58;font-size:11px;">No technologies detected</span>';

  const sectionSSL = document.getElementById('section-ssl');
  const sslInfo = document.getElementById('ssl-info');
  if (currentURL.startsWith('https://')) {
    sectionSSL.classList.remove('hidden');
    sslInfo.innerHTML = '<div class="list-item pass"><span class="item-icon">&#9989;</span><span class="item-content">Using HTTPS - connection appears secure</span></div>';
  } else if (currentURL.startsWith('http://')) {
    sectionSSL.classList.remove('hidden');
    sslInfo.innerHTML = '<div class="list-item fail"><span class="item-icon">&#10060;</span><span class="item-content">Using HTTP - traffic is unencrypted!</span></div>';
  } else {
    sectionSSL.classList.add('hidden');
  }
}

function renderError(msg) {
  resultsDiv.classList.remove('hidden');
  document.getElementById('vulns-list').innerHTML = `<div class="vuln-item severity-high"><div class="vuln-header"><span class="vuln-severity high">ERROR</span><span class="vuln-title">Scan Failed</span></div><div class="vuln-desc">${esc(msg)}</div></div>`;
}

function getHeaderSeverity(name) {
  const map = { 'Strict-Transport-Security': 'critical', 'Content-Security-Policy': 'high', 'X-Frame-Options': 'high', 'X-Content-Type-Options': 'medium', 'Referrer-Policy': 'medium' };
  return map[name] || 'info';
}

function showScanning(showing) {
  if (showing) { scanningStatus.classList.remove('hidden'); scanBtn.style.opacity = '0.5'; scanBtn.disabled = true; }
  else { scanningStatus.classList.add('hidden'); scanBtn.style.opacity = '1'; scanBtn.disabled = false; }
}

function hideResults() { resultsDiv.classList.add('hidden'); emptyStateDiv.classList.add('hidden'); }
function esc(str) { if (!str) return ''; const d = document.createElement('div'); d.textContent = str; return d.innerHTML; }
