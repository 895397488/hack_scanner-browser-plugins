// Hack Scanner Background Service Worker
// Lightweight: stores config, no heavy scanning in service worker

let config = { autoScan: true };

chrome.storage.local.get(['config'], (items) => {
  if (items.config) config = { ...config, ...items.config };
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'getConfig') {
    sendResponse(config);
    return true;
  }
  if (message.type === 'updateConfig') {
    config = { ...config, ...message.config };
    chrome.storage.local.set({ config });
    sendResponse({ ok: true });
    return true;
  }
});

console.log('[HackScanner] Background ready');
