// Hack Scanner Content Script
// Only used for DOM-level fingerprint data via chrome.scripting.executeScript

if (typeof window !== 'undefined') {
  window._hackScannerFingerprint = function() {
    const techs = [];
    const body = document.body?.innerHTML || '';

    // Detect frameworks from scripts/variables
    if (window.jQuery || body.includes('jquery')) techs.push({ name: 'jQuery', category: 'Frontend', source: 'JS var / DOM' });
    if (window.React || window.__REACT_DEVTOOLS__) techs.push({ name: 'React', category: 'Frontend', source: 'JS var' });
    if (window.Vue) techs.push({ name: 'Vue.js', category: 'Frontend', source: 'JS var' });
    if (window.angular) techs.push({ name: 'Angular', category: 'Frontend', source: 'JS var' });

    // CMS detection
    if (body.includes('wp-content') || body.includes('wp-includes')) techs.push({ name: 'WordPress', category: 'CMS', source: 'DOM' });
    if (body.includes('woocommerce')) techs.push({ name: 'WooCommerce', category: 'E-commerce', source: 'DOM' });

    // CDNs from script tags
    document.querySelectorAll('script[src]').forEach(s => {
      const src = s.src || '';
      if (src.includes('cloudflare')) techs.push({ name: 'Cloudflare', category: 'CDN', source: 'Script' });
      if (src.includes('cloudfront.net')) techs.push({ name: 'AWS CloudFront', category: 'CDN', source: 'Script' });
      if (src.includes('google-analytics')) techs.push({ name: 'Google Analytics', category: 'Analytics', source: 'Script' });
      if (src.includes('cdn.shopify')) techs.push({ name: 'Shopify', category: 'E-commerce', source: 'Script' });
    });

    return { techs };
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'get-fingerprint') {
    const data = window._hackScannerFingerprint?.() || { techs: [] };
    sendResponse(data);
  }
});
